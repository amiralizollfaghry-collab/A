package com.zai.chat;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    // Replace with your deployed Z AI website URL (HTTPS) before building.
    private static final String APP_URL = "https://YOUR-ZAI-SERVER.example";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8,13,27));
        getWindow().setNavigationBarColor(Color.rgb(8,13,27));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(8,13,27));
        WebView web = new WebView(this);
        web.setBackgroundColor(Color.rgb(8,13,27));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        if (APP_URL.contains("YOUR-ZAI-SERVER")) {
            TextView message = new TextView(this);
            message.setText("Z AI\n\nبرای فعال شدن، آدرس HTTPS سایت Z AI را در MainActivity.java وارد کن و دوباره APK بساز.\n\nکلید API را هرگز داخل اپ قرار نده؛ فقط روی سرور نگه دار.");
            message.setTextColor(Color.WHITE);
            message.setTextSize(18);
            message.setGravity(Gravity.CENTER);
            message.setPadding(24,24,24,24);
            root.addView(message, 0, new LinearLayout.LayoutParams(-1, -2));
        } else {
            web.loadUrl(APP_URL);
        }
    }
}
